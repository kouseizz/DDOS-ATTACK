go to the main directory 
install python if u dont have it
while installing python please add it to path via checking the box at the bottom of the installer window
run install_requirements.bat to install requirements automatically
